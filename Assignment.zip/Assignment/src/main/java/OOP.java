import java.util.ArrayList;
import java.util.List;

// Define an interface for making sounds.
interface SoundMaker {
    void makeSound();
}

// Animal is an abstract class implementing the SoundMaker interface.
abstract class Animal implements SoundMaker {
    private String name;
    private int age;

    public Animal(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    // All subclasses must provide their specific implementation of makeSound.
    public abstract void makeSound();
}

// Herbivore and Carnivore are concrete subclasses of Animal.
class Herbivore extends Animal {
    public Herbivore(String name, int age) {
        super(name, age);
    }

    @Override
    public void makeSound() {
        System.out.println(getName() + " makes a herbivore-specific sound.");
    }

    public void eatPlant() {
        System.out.println(getName() + " is eating plants.");
    }
}

class Carnivore extends Animal {
    public Carnivore(String name, int age) {
        super(name, age);
    }

    @Override
    public void makeSound() {
        System.out.println(getName() + " makes a carnivore-specific sound.");
    }

    public void eatMeat() {
        System.out.println(getName() + " is eating meat.");
    }
}

// Zoo class represents the collection of animals in the zoo using Generics.
class Zoo<T extends Animal> {
    private List<T> animals;

    public Zoo() {
        animals = new ArrayList<>();
    }

    // Add an animal to the zoo.
    public void addAnimal(T animal) {
        animals.add(animal);
    }

    // Perform sounds of all animals in the zoo.
    public void performAnimalSounds() {
        for (T animal : animals) {
            animal.makeSound();
        }
    }
}
