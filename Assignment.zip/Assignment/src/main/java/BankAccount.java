import java.util.concurrent.locks.ReentrantLock;

// Custom exception for insufficient funds during a withdrawal
class InsufficientFundsException extends Exception {
    public InsufficientFundsException(String message) {
        super(message);
    }
}

// BankAccount class for managing a bank account's balance
class BankAccount {
    private double balance;
    private ReentrantLock lock;

    public BankAccount(double initialBalance) {
        balance = initialBalance;
        lock = new ReentrantLock();
    }

    // Deposit money into the account
    public void deposit(double amount) {
        lock.lock();
        try {
            balance += amount;
            System.out.println("Deposited: " + amount + ", New Balance: " + balance);
        } finally {
            lock.unlock();
        }
    }

    // Withdraw money from the account, throwing an exception if funds are insufficient
    public void withdraw(double amount) throws InsufficientFundsException {
        lock.lock();
        try {
            if (balance >= amount) {
                balance -= amount;
                System.out.println("Withdrawn: " + amount + ", New Balance: " + balance);
            } else {
                throw new InsufficientFundsException("Insufficient balance for withdrawal.");
            }
        } finally {
            lock.unlock();
        }
    }

    // Get the current balance
    public double getBalance() {
        return balance;
    }
}

// Transaction class to represent a bank transaction
class Transaction {
    private String type;
    private double amount;

    public Transaction(String type, double amount) {
        this.type = type;
        this.amount = amount;
    }

    public String getType() {
        return type;
    }

    public double getAmount() {
        return amount;
    }

    @Override
    public String toString() {
        return type + " of " + amount;
    }
}

// CustomLinkedList class to implement a simple linked list
class CustomLinkedList<T> {
    private Node<T> head;
    private int size;

    public CustomLinkedList() {
        head = null;
        size = 0;
    }

    // Add an element to the linked list
    public void add(T data) {
        Node<T> newNode = new Node<>(data);
        if (head == null) {
            head = newNode;
        } else {
            Node<T> current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
        size++;
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        Node<T> current = head;
        while (current != null) {
            result.append(current.data);
            if (current.next != null) {
                result.append(" -> ");
            }
            current = current.next;
        }
        return result.toString();
    }
}

// Node class for the CustomLinkedList
class Node<T> {
    T data;
    Node<T> next;

    public Node(T data) {
        this.data = data;
        this.next = null;
    }
}

// Customer class representing a bank customer using threads
class Customer extends Thread {
    private BankAccount account;
    private double transactionAmount;
    private boolean isDeposit;
    private CustomLinkedList<Transaction> transactionHistory;

    public Customer(BankAccount account, double transactionAmount, boolean isDeposit) {
        this.account = account;
        this.transactionAmount = transactionAmount;
        this.isDeposit = isDeposit;
        this.transactionHistory = new CustomLinkedList<>();
    }

    @Override
    public void run() {
        if (isDeposit) {
            account.deposit(transactionAmount);
            transactionHistory.add(new Transaction("Deposit", transactionAmount));
        } else {
            try {
                account.withdraw(transactionAmount);
                transactionHistory.add(new Transaction("Withdrawal", transactionAmount));
            } catch (InsufficientFundsException e) {
                System.out.println("Exception: " + e.getMessage());
            }
        }
    }

    // Get the transaction history for the customer
    public CustomLinkedList<Transaction> getTransactionHistory() {
        return transactionHistory;
    }
}
