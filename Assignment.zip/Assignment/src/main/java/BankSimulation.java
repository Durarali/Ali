import java.util.concurrent.locks.ReentrantLock;
import java.io.*;

public class BankSimulation {
    public static void main(String[] args) {
        // Create a BankAccount instance with an initial balance of 1000
        BankAccount account = new BankAccount(1000);

        // Read transactions from input.txt and process them
        String inputFilePath = "input.txt"; // Specify the input file path

        try {
            // Open a BufferedReader to read from the input file
            BufferedReader reader = new BufferedReader(new FileReader(inputFilePath));
            String line;
            double depositAmount = 0;

            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Deposit:")) {
                    // If the line starts with "Deposit:", extract the deposit amount and deposit it
                    depositAmount = Double.parseDouble(line.substring("Deposit:".length()).trim());
                    account.deposit(depositAmount); // Deposit the specified amount
                } else if (line.startsWith("Withdrawal:")) {
                    // If the line starts with "Withdrawal:", extract the withdrawal amount and attempt a withdrawal
                    double withdrawalAmount = Double.parseDouble(line.substring("Withdrawal:".length()).trim());
                    try {
                        account.withdraw(withdrawalAmount); // Withdraw the specified amount
                    } catch (InsufficientFundsException e) {
                        System.out.println("Exception: " + e.getMessage());
                    }
                }
            }
            reader.close(); // Close the input file
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Store the updated balance in output.txt
        String outputFilePath = "output.txt"; // Specify the output file path

        try {
            // Open a BufferedWriter to write the updated balance to the output file
            BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath));
            writer.write("Updated Balance: " + account.getBalance());
            writer.close(); // Close the output file

            // Print the updated balance to the console
            System.out.println("Updated Balance: " + account.getBalance());
            System.out.println("Updated balance written to " + outputFilePath);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Display transaction history for each customer
        for (Thread t : Thread.getAllStackTraces().keySet()) {
            if (t instanceof Customer) {
                Customer customer = (Customer) t;
                CustomLinkedList<Transaction> history = customer.getTransactionHistory();
                System.out.println("Transaction History for Customer " + customer.getId() + ": " + history.toString());
            }
        }
    }
}
