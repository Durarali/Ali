/**
 * This class serves as the entry point of the program and demonstrates the use of the Zoo class.
 * It creates a zoo with different types of animals and performs their sounds.
 */
public class Main {
    public static void main(String[] args) {
        // Create a new Zoo instance to hold animals.
        Zoo<Animal> zoo = new Zoo<>();

        // Create a Carnivore (lion) and a Herbivore (giraffe) with specific names and ages.
        Animal lion = new Carnivore("Simba", 5);
        Animal giraffe = new Herbivore("Gerty", 7);

        // Add the animals to the zoo.
        zoo.addAnimal(lion);
        zoo.addAnimal(giraffe);

        // Perform the sounds made by the animals in the zoo.
        zoo.performAnimalSounds();
    }
}
